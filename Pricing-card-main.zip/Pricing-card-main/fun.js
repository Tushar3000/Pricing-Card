function alertUser()
{
  alert('clicked on sign up');
}
